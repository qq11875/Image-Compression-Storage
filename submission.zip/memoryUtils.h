
void freeImageData(ImageData *imageData);

int allocate2DArrayMemory(ImageData *imageData, int height, int width);