
void reportError(int errorValue, const char *fileName);